// Entity class




function getComponentName(entity_name, component_name)
{

  return "__" + entity_name + "__" + component_name;


}




Entity.prototype.component_data;
Entity.prototype.entity_data;
Entity.prototype.name;







function Entity(name,
  component_data,
  entity_data) {


    this.name = name;
    this.component_data = component_data;
    this.entity_data = entity_data;

  }





  Entity.prototype.addComponent = function(new_component)
  {


    var type = new_component.type;
    var name = getComponentName(this.name, new_component.name);


    if (this.component_data[type] == undefined)
    this.component_data[type] = {};

    

    delete new_component.type;
    delete new_component.name;



    if (type == "Mesh")
    new_component.transform = "__" + this.name + "__" + new_component.transform;



    this.component_data[type][name] = new_component;


  }





  Entity.prototype.toString = function()
  {

  }
